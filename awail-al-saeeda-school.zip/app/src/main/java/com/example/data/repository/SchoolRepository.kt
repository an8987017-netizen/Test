package com.example.data.repository

import com.example.data.local.*
import kotlinx.coroutines.flow.Flow

class SchoolRepository(private val dao: SchoolDao) {
    val users: Flow<List<UserEntity>> = dao.getAllUsers()
    val subjects: Flow<List<SubjectEntity>> = dao.getAllSubjects()
    val assignments: Flow<List<AssignmentEntity>> = dao.getAllAssignments()
    val exams: Flow<List<ExamEntity>> = dao.getAllExams()
    val attendance: Flow<List<AttendanceEntity>> = dao.getAllAttendance()
    val announcements: Flow<List<AnnouncementEntity>> = dao.getAllAnnouncements()
    val grades: Flow<List<GradeEntity>> = dao.getAllGrades()

    fun getMessages(roomName: String): Flow<List<ChatMessageEntity>> = dao.getMessagesForRoom(roomName)

    suspend fun getUserByEmail(email: String): UserEntity? = dao.getUserByEmail(email)
    suspend fun insertUser(user: UserEntity) = dao.insertUser(user)

    suspend fun insertAssignment(assignment: AssignmentEntity) = dao.insertAssignment(assignment)
    suspend fun updateAssignmentStatus(id: Long, submitted: Boolean, grade: String?) = dao.updateAssignmentStatus(id, submitted, grade)

    suspend fun insertExam(exam: ExamEntity) = dao.insertExam(exam)
    suspend fun updateExamResult(id: Long, completed: Boolean, marks: Int) = dao.updateExamResult(id, completed, marks)

    suspend fun insertAttendance(attendance: AttendanceEntity) = dao.insertAttendance(attendance)
    suspend fun insertAnnouncement(announcement: AnnouncementEntity) = dao.insertAnnouncement(announcement)
    suspend fun insertMessage(message: ChatMessageEntity) = dao.insertMessage(message)
    suspend fun insertGrade(grade: GradeEntity) = dao.insertGrade(grade)
    suspend fun insertSubject(subject: SubjectEntity) = dao.insertSubject(subject)
}
