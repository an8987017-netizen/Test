package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        SubjectEntity::class,
        AssignmentEntity::class,
        ExamEntity::class,
        AttendanceEntity::class,
        AnnouncementEntity::class,
        ChatMessageEntity::class,
        GradeEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SchoolDatabase : RoomDatabase() {
    abstract fun schoolDao(): SchoolDao

    companion object {
        @Volatile
        private var INSTANCE: SchoolDatabase? = null

        fun getDatabase(context: Context): SchoolDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SchoolDatabase::class.java,
                    "awail_al_saeeda_database"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(SchoolDatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class SchoolDatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database.schoolDao())
                    }
                }
            }

            suspend fun populateInitialData(dao: SchoolDao) {
                // Users
                dao.insertUser(UserEntity(name = "أحمد محمد العريقي", role = "student", email = "ahmed@awail.edu", phone = "771234567", className = "الصف الأول الثانوي", avatarEmoji = "🎓"))
                dao.insertUser(UserEntity(name = "أ. فاطمة الزهراء", role = "teacher", email = "fatima@awail.edu", phone = "772345678", className = "الصف الأول الثانوي", avatarEmoji = "👩‍🏫"))
                dao.insertUser(UserEntity(name = "محمد العريقي (ولي الأمر)", role = "parent", email = "parent@awail.edu", phone = "773456789", className = "الصف الأول الثانوي", avatarEmoji = "👨‍👦"))
                dao.insertUser(UserEntity(name = "د. عبدالرحمن السقاف (المدير)", role = "admin", email = "admin@awail.edu", phone = "774567890", className = "الإدارة المدرسية", avatarEmoji = "🏛️"))

                // Subjects
                dao.insertSubject(SubjectEntity(name = "الرياضيات المتقدمة", teacherName = "أ. فاطمة الزهراء", className = "الصف الأول الثانوي", scheduleTime = "الأحد 08:00 ص"))
                dao.insertSubject(SubjectEntity(name = "القرآن الكريم والتربية الإسلامية", teacherName = "أ. عبدالله القاضي", className = "الصف الأول الثانوي", scheduleTime = "الأحد 09:30 ص"))
                dao.insertSubject(SubjectEntity(name = "اللغة العربية وقواعدها", teacherName = "أ. سمير اليمن", className = "الصف الأول الثانوي", scheduleTime = "الإثنين 08:00 ص"))
                dao.insertSubject(SubjectEntity(name = "الفيزياء والتطبيقات العملية", teacherName = "أ. نبيل الكثيري", className = "الصف الأول الثانوي", scheduleTime = "الثلاثاء 10:00 ص"))
                dao.insertSubject(SubjectEntity(name = "الكيمياء العامة", teacherName = "د. منى العديني", className = "الصف الأول الثانوي", scheduleTime = "الأربعاء 09:00 ص"))

                // Assignments
                dao.insertAssignment(AssignmentEntity(title = "حل تمارين التفاضل والتكامل صف 45", subject = "الرياضيات المتقدمة", description = "يرجى حل التمارين من 1 إلى 10 في الدفتر وتصوير الحل.", dueDate = "2026-08-15", isSubmitted = false))
                dao.insertAssignment(AssignmentEntity(title = "إعراب سورة الحجرات (الآيات 1-5)", subject = "اللغة العربية وقواعدها", description = "كتابة الإعراب كاملاً بخط واضح.", dueDate = "2026-08-18", isSubmitted = true, grade = "95%"))
                dao.insertAssignment(AssignmentEntity(title = "بحث عن قوانين نيوتن للحركة", subject = "الفيزياء والتطبيقات العملية", description = "تقديم تقرير من صفحتين مع الأمثلة الحياتية.", dueDate = "2026-08-20", isSubmitted = false))

                // Exams
                dao.insertExam(ExamEntity(title = "اختبار منتصف الفصل الأول في الرياضيات", subject = "الرياضيات المتقدمة", date = "2026-08-25", durationMinutes = 30, totalMarks = 20, isCompleted = false))
                dao.insertExam(ExamEntity(title = "اختبار قصير في قواعد النحو", subject = "اللغة العربية وقواعدها", date = "2026-08-12", durationMinutes = 15, totalMarks = 10, isCompleted = true, obtainedMarks = 9))

                // Attendance
                dao.insertAttendance(AttendanceEntity(studentName = "أحمد محمد العريقي", date = "2026-08-11", status = "present", className = "الصف الأول الثانوي"))
                dao.insertAttendance(AttendanceEntity(studentName = "أحمد محمد العريقي", date = "2026-08-10", status = "present", className = "الصف الأول الثانوي"))
                dao.insertAttendance(AttendanceEntity(studentName = "أحمد محمد العريقي", date = "2026-08-09", status = "late", className = "الصف الأول الثانوي"))

                // Announcements
                dao.insertAnnouncement(AnnouncementEntity(title = "موعد بدء الامتحانات النهائية", content = "تعلن إدارة مدرسة أوائل السعيدة عن بدء الامتحانات النهائية للفصل الدراسي الأول يوم السبت الموافق 25 أغسطس 2026.", date = "2026-08-10", sender = "الإدارة المدرسية"))
                dao.insertAnnouncement(AnnouncementEntity(title = "رحلة مدرسية تعليمية", content = "سيتم تنظيم رحلة علمية لطلاب الصف الأول الثانوي إلى مركز العلوم والتكنولوجيا يوم الخميس القادم.", date = "2026-08-08", sender = "أ. فاطمة الزهراء"))

                // Chat Messages
                dao.insertMessage(ChatMessageEntity(roomName = "مجموعة أول ثانوي", senderName = "أ. فاطمة الزهراء", senderRole = "teacher", message = "أهلاً بكم يا طلاب مدرسة أوائل السعيدة. تذكروا تسليم واجب الرياضيات في موعده.", timestamp = System.currentTimeMillis() - 3600000))
                dao.insertMessage(ChatMessageEntity(roomName = "مجموعة أول ثانوي", senderName = "أحمد محمد العريقي", senderRole = "student", message = "حسناً يا أستاذة، لقد انهيت التمارين وسأقوم بتسليمها اليوم.", timestamp = System.currentTimeMillis() - 1800000))
                dao.insertMessage(ChatMessageEntity(roomName = "الإدارة المدرسية", senderName = "د. عبدالرحمن السقاف", senderRole = "admin", message = "تنويه لجميع اولياء الأمور: تم تفعيل البوابة الرقمية للمتابعة اليومية عبر التطبيق.", timestamp = System.currentTimeMillis() - 7200000))

                // Grades
                dao.insertGrade(GradeEntity(studentName = "أحمد محمد العريقي", subject = "الرياضيات المتقدمة", examTitle = "الاختبار الشهري الأول", score = 18, maxScore = 20, term = "الفصل الأول"))
                dao.insertGrade(GradeEntity(studentName = "أحمد محمد العريقي", subject = "اللغة العربية وقواعدها", examTitle = "الاختبار الشهري الأول", score = 19, maxScore = 20, term = "الفصل الأول"))
                dao.insertGrade(GradeEntity(studentName = "أحمد محمد العريقي", subject = "الفيزياء والتطبيقات العملية", examTitle = "الاختبار الشهري الأول", score = 17, maxScore = 20, term = "الفصل الأول"))
            }
        }
    }
}
