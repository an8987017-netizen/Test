package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.viewmodel.SchoolViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParentDashboardScreen(
    viewModel: SchoolViewModel,
    onLogout: () -> Unit
) {
    val attendance by viewModel.attendance.collectAsState()
    val grades by viewModel.grades.collectAsState()
    val announcements by viewModel.announcements.collectAsState()
    val userName by viewModel.currentUserName.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("👨‍👦", fontSize = 22.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(userName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("ولي أمر - مدرسة أوائل السعيدة", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onLogout) {
                        Icon(Icons.Default.Logout, contentDescription = "تسجيل الخروج", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize().background(MaterialTheme.colorScheme.background).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("أهلاً بك يا $userName", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("تابع مستوى أبنائك الدراسي، الحضور، والدرجات مباشرة عبر منصة مدرسة أوائل السعيدة.", color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                        Text("👨‍👦", fontSize = 36.sp)
                    }
                }
            }

            item { Text("درجات ونتائج الطالب", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
            items(grades) { grade ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(grade.subject, fontWeight = FontWeight.Bold)
                            Text("${grade.examTitle} • ${grade.term}", style = MaterialTheme.typography.bodySmall)
                        }
                        Badge(containerColor = MaterialTheme.colorScheme.primaryContainer) {
                            Text("${grade.score}/${grade.maxScore}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(6.dp))
                        }
                    }
                }
            }

            item { Text("سجل الحضور والغياب", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
            items(attendance) { att ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(att.studentName, fontWeight = FontWeight.Bold)
                            Text("التاريخ: ${att.date}", style = MaterialTheme.typography.bodySmall)
                        }
                        Badge(containerColor = if (att.status == "present") MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer) {
                            Text(if (att.status == "present") "حاضر" else "غائب", modifier = Modifier.padding(6.dp))
                        }
                    }
                }
            }
        }
    }
}
