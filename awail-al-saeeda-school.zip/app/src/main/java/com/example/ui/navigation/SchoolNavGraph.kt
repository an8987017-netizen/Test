package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.viewmodel.SchoolViewModel
import com.example.ui.screens.*
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

@Composable
fun SchoolNavGraph() {
    val navController = rememberNavController()
    val viewModel: SchoolViewModel = viewModel()

    NavHost(navController = navController, startDestination = "splash") {
        composable("splash") {
            SplashScreen(
                viewModel = viewModel,
                onNavigate = { route ->
                    navController.navigate(route) {
                        popUpTo("splash") { inclusive = true }
                    }
                }
            )
        }
        composable("login") {
            LoginScreen(
                viewModel = viewModel,
                onLoginSuccess = { role ->
                    val destination = when (role) {
                        "teacher" -> "teacher_dashboard"
                        "parent" -> "parent_dashboard"
                        "admin" -> "admin_dashboard"
                        else -> "student_dashboard"
                    }
                    navController.navigate(destination) {
                        popUpTo("login") { inclusive = true }
                    }
                }
            )
        }
        composable("student_dashboard") {
            StudentDashboardScreen(
                viewModel = viewModel,
                onNavigateToExam = { examId -> navController.navigate("exam_taker/$examId") },
                onNavigateToChat = { roomName ->
                    val encoded = URLEncoder.encode(roomName, StandardCharsets.UTF_8.toString())
                    navController.navigate("chat/$encoded")
                },
                onLogout = {
                    viewModel.logoutUser {
                        navController.navigate("login") {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                }
            )
        }
        composable("teacher_dashboard") {
            TeacherDashboardScreen(
                viewModel = viewModel,
                onNavigateToChat = { roomName ->
                    val encoded = URLEncoder.encode(roomName, StandardCharsets.UTF_8.toString())
                    navController.navigate("chat/$encoded")
                },
                onLogout = {
                    viewModel.logoutUser {
                        navController.navigate("login") {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                }
            )
        }
        composable("parent_dashboard") {
            ParentDashboardScreen(
                viewModel = viewModel,
                onLogout = {
                    viewModel.logoutUser {
                        navController.navigate("login") {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                }
            )
        }
        composable("admin_dashboard") {
            AdminDashboardScreen(
                viewModel = viewModel,
                onLogout = {
                    viewModel.logoutUser {
                        navController.navigate("login") {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                }
            )
        }
        composable(
            route = "exam_taker/{examId}",
            arguments = listOf(navArgument("examId") { type = NavType.LongType })
        ) { backStackEntry ->
            val examId = backStackEntry.arguments?.getLong("examId") ?: 1L
            ExamTakerScreen(
                examId = examId,
                viewModel = viewModel,
                onFinish = { navController.popBackStack() }
            )
        }
        composable(
            route = "chat/{roomName}",
            arguments = listOf(navArgument("roomName") { type = NavType.StringType })
        ) { backStackEntry ->
            val encoded = backStackEntry.arguments?.getString("roomName") ?: ""
            val roomName = URLDecoder.decode(encoded, StandardCharsets.UTF_8.toString())
            ChatScreen(
                roomName = roomName,
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
