package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.viewmodel.SchoolViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherDashboardScreen(
    viewModel: SchoolViewModel,
    onNavigateToChat: (String) -> Unit,
    onLogout: () -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    var showAddAssignment by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }
    var newDesc by remember { mutableStateOf("") }

    val subjects by viewModel.subjects.collectAsState()
    val assignments by viewModel.assignments.collectAsState()
    val attendance by viewModel.attendance.collectAsState()
    val userName by viewModel.currentUserName.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("👩‍🏫", fontSize = 22.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(userName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("معلم - مدرسة أوائل السعيدة", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onLogout) {
                        Icon(Icons.Default.Logout, contentDescription = "تسجيل الخروج", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        floatingActionButton = {
            if (tab == 1) {
                FloatingActionButton(onClick = { showAddAssignment = true }, containerColor = MaterialTheme.colorScheme.primary) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة واجب", tint = MaterialTheme.colorScheme.onPrimary)
                }
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") }, selected = tab == 0, onClick = { tab = 0 })
                NavigationBarItem(icon = { Icon(Icons.Default.Assignment, null) }, label = { Text("الواجبات") }, selected = tab == 1, onClick = { tab = 1 })
                NavigationBarItem(icon = { Icon(Icons.Default.HowToReg, null) }, label = { Text("الحضور") }, selected = tab == 2, onClick = { tab = 2 })
                NavigationBarItem(icon = { Icon(Icons.Default.Chat, null) }, label = { Text("المحادثات") }, selected = tab == 3, onClick = { tab = 3 })
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            when (tab) {
                0 -> {
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("أهلاً بك أ. $userName", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("يمكنك إدارة الحصص، رصد الحضور، وإضافة الواجبات للطلاب بكل سهولة عبر منصة مدرسة أوائل السعيدة.", color = MaterialTheme.colorScheme.onPrimaryContainer)
                                    }
                                    Text("📚", fontSize = 36.sp)
                                }
                            }
                        }
                        item { Text("الحصص المسندة إليك", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                        items(subjects) { sub ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("📖", fontSize = 24.sp)
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(sub.name, fontWeight = FontWeight.Bold)
                                        Text("الصف: ${sub.className} • ${sub.scheduleTime}", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Text("الواجبات المنشورة", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Spacer(modifier = Modifier.weight(1f))
                                Button(onClick = { showAddAssignment = true }) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("واجب جديد")
                                }
                            }
                        }
                        items(assignments) { asn ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(asn.subject, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(asn.title, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(asn.description, style = MaterialTheme.typography.bodyMedium)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("موعد التسليم: ${asn.dueDate}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
                2 -> {
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Text("سجل حضور الطلاب", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Spacer(modifier = Modifier.weight(1f))
                                Button(onClick = { viewModel.recordAttendance("أحمد محمد العريقي", "present", "الصف الأول الثانوي") }) {
                                    Text("تسجيل حضور طالب")
                                }
                            }
                        }
                        items(attendance) { att ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(att.studentName, fontWeight = FontWeight.Bold)
                                        Text("الصف: ${att.className} • التاريخ: ${att.date}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    Badge(containerColor = if (att.status == "present") MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer) {
                                        Text(if (att.status == "present") "حاضر" else "متأخر / غائب", modifier = Modifier.padding(6.dp))
                                    }
                                }
                            }
                        }
                    }
                }
                3 -> {
                    val rooms = listOf("مجموعة أول ثانوي", "نقاشات الرياضيات", "الإدارة المدرسية")
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item { Text("المحادثات الجماعية", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                        items(rooms) { room ->
                            Card(modifier = Modifier.clickable { onNavigateToChat(room) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("💬", fontSize = 24.sp)
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(room, fontWeight = FontWeight.Bold)
                                        Text("انقر للدخول للمحادثة", style = MaterialTheme.typography.bodySmall)
                                    }
                                    Icon(Icons.Default.ArrowForwardIos, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddAssignment) {
        AlertDialog(
            onDismissRequest = { showAddAssignment = false },
            title = { Text("إضافة واجب جديد") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("عنوان الواجب") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newDesc,
                        onValueChange = { newDesc = it },
                        label = { Text("تفاصيل الواجب") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (newTitle.isNotBlank()) {
                        viewModel.addAssignment(newTitle, "المادة الدراسية", newDesc, "2026-08-30")
                        newTitle = ""
                        newDesc = ""
                        showAddAssignment = false
                    }
                }) {
                    Text("نشر الواجب")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddAssignment = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
