package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryGreen = Color(0xFF0F5132)
val OnPrimaryGreen = Color(0xFFFFFFFF)
val PrimaryContainerGreen = Color(0xFFD1E7DD)
val OnPrimaryContainerGreen = Color(0xFF0A3622)

val SecondaryGold = Color(0xFF856404)
val OnSecondaryGold = Color(0xFFFFFFFF)
val SecondaryContainerGold = Color(0xFFFFF3CD)
val OnSecondaryContainerGold = Color(0xFF533F03)

val BackgroundLight = Color(0xFFF8F9FA)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF212529)
val OutlineLight = Color(0xFFDEE2E6)

val PrimaryDark = Color(0xFF75B798)
val OnPrimaryDark = Color(0xFF0A3622)
val BackgroundDark = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)
val OnSurfaceDark = Color(0xFFF8F9FA)
