package com.example.data.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import com.example.data.repository.SchoolRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class SchoolViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: SchoolRepository
    private val auth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()

    init {
        val db = SchoolDatabase.getDatabase(application)
        repository = SchoolRepository(db.schoolDao())
        checkCurrentUserAndFetchProfile()
    }

    private val _currentRole = MutableStateFlow("student")
    val currentRole: StateFlow<String> = _currentRole.asStateFlow()

    private val _currentUserName = MutableStateFlow("مستخدم النظام")
    val currentUserName: StateFlow<String> = _currentUserName.asStateFlow()

    fun setRole(role: String) {
        _currentRole.value = role
    }

    fun checkCurrentUserAndFetchProfile(onResult: ((String?) -> Unit)? = null) {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            viewModelScope.launch {
                try {
                    val doc = firestore.collection("users").document(currentUser.uid).get().await()
                    if (doc.exists()) {
                        val role = doc.getString("role") ?: "student"
                        val name = doc.getString("name") ?: (currentUser.email ?: "مستخدم")
                        _currentRole.value = role
                        _currentUserName.value = name
                        onResult?.invoke(role)
                    } else {
                        // Create default user profile in Firestore if missing
                        val defaultRole = "student"
                        val defaultName = currentUser.email ?: "طالب المنصة"
                        val userData = mapOf(
                            "uid" to currentUser.uid,
                            "email" to (currentUser.email ?: ""),
                            "name" to defaultName,
                            "role" to defaultRole,
                            "phone" to "",
                            "className" to "الصف الأول الثانوي"
                        )
                        firestore.collection("users").document(currentUser.uid).set(userData).await()
                        _currentRole.value = defaultRole
                        _currentUserName.value = defaultName
                        onResult?.invoke(defaultRole)
                    }
                } catch (e: Exception) {
                    // Fallback to offline / local state if offline
                    val role = "student"
                    _currentRole.value = role
                    _currentUserName.value = currentUser.email ?: "مستخدم"
                    onResult?.invoke(role)
                }
            }
        } else {
            onResult?.invoke(null)
        }
    }

    fun loginUser(email: String, password: String, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                checkCurrentUserAndFetchProfile { role ->
                    if (role != null) onSuccess(role) else onSuccess("student")
                }
            }
            .addOnFailureListener { e ->
                // Fallback to local Room authentication if Firebase Auth fails (e.g. invalid API key or offline)
                viewModelScope.launch {
                    val localUser = repository.getUserByEmail(email)
                    if (localUser != null) {
                        _currentRole.value = localUser.role
                        _currentUserName.value = localUser.name
                        onSuccess(localUser.role)
                    } else {
                        when (email.lowercase()) {
                            "ahmed@awail.edu" -> {
                                _currentRole.value = "student"
                                _currentUserName.value = "أحمد محمد العريقي"
                                onSuccess("student")
                            }
                            "fatima@awail.edu" -> {
                                _currentRole.value = "teacher"
                                _currentUserName.value = "أ. فاطمة الزهراء"
                                onSuccess("teacher")
                            }
                            "parent@awail.edu" -> {
                                _currentRole.value = "parent"
                                _currentUserName.value = "محمد العريقي (ولي الأمر)"
                                onSuccess("parent")
                            }
                            "admin@awail.edu" -> {
                                _currentRole.value = "admin"
                                _currentUserName.value = "د. عبدالرحمن السقاف (المدير)"
                                onSuccess("admin")
                            }
                            else -> {
                                onError(e.localizedMessage ?: "فشل تسجيل الدخول")
                            }
                        }
                    }
                }
            }
    }

    fun registerUser(email: String, password: String, name: String, role: String, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                val uid = result.user?.uid ?: return@addOnSuccessListener
                val userData = mapOf(
                    "uid" to uid,
                    "email" to email,
                    "name" to name,
                    "role" to role,
                    "phone" to "",
                    "className" to "الصف الأول الثانوي"
                )
                firestore.collection("users").document(uid).set(userData)
                    .addOnSuccessListener {
                        _currentRole.value = role
                        _currentUserName.value = name
                        onSuccess(role)
                    }
                    .addOnFailureListener { e ->
                        onError(e.localizedMessage ?: "فشل حفظ بيانات المستخدم")
                    }
            }
            .addOnFailureListener { e ->
                // Fallback to local Room registration when Firebase Auth fails (e.g. invalid API key)
                viewModelScope.launch {
                    try {
                        repository.insertUser(
                            UserEntity(
                                name = name,
                                role = role,
                                email = email,
                                phone = "",
                                className = "الصف الأول الثانوي",
                                avatarEmoji = when(role) { "teacher" -> "👩‍🏫"; "parent" -> "👨‍👦"; "admin" -> "🏛️"; else -> "🎓" }
                            )
                        )
                        _currentRole.value = role
                        _currentUserName.value = name
                        onSuccess(role)
                    } catch (ex: Exception) {
                        onError(e.localizedMessage ?: "فشل إنشاء الحساب")
                    }
                }
            }
    }

    fun logoutUser(onComplete: () -> Unit) {
        auth.signOut()
        onComplete()
    }

    val users: StateFlow<List<UserEntity>> = repository.users
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val subjects: StateFlow<List<SubjectEntity>> = repository.subjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val assignments: StateFlow<List<AssignmentEntity>> = repository.assignments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val exams: StateFlow<List<ExamEntity>> = repository.exams
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val attendance: StateFlow<List<AttendanceEntity>> = repository.attendance
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val announcements: StateFlow<List<AnnouncementEntity>> = repository.announcements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val grades: StateFlow<List<GradeEntity>> = repository.grades
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeChatRoom = MutableStateFlow("مجموعة أول ثانوي")
    val activeChatRoom: StateFlow<String> = _activeChatRoom.asStateFlow()

    fun setActiveChatRoom(room: String) {
        _activeChatRoom.value = room
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val chatMessages: StateFlow<List<ChatMessageEntity>> = _activeChatRoom
        .flatMapLatest { room -> repository.getMessages(room) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun sendMessage(roomName: String, senderName: String, senderRole: String, messageText: String) {
        if (messageText.isBlank()) return
        viewModelScope.launch {
            val msg = ChatMessageEntity(
                roomName = roomName,
                senderName = senderName,
                senderRole = senderRole,
                message = messageText
            )
            repository.insertMessage(msg)
            // Sync to Firestore
            try {
                firestore.collection("chat_messages").add(
                    mapOf(
                        "roomName" to roomName,
                        "senderName" to senderName,
                        "senderRole" to senderRole,
                        "message" to messageText,
                        "timestamp" to System.currentTimeMillis()
                    )
                )
            } catch (_: Exception) {}
        }
    }

    fun submitAssignment(id: Long) {
        viewModelScope.launch {
            repository.updateAssignmentStatus(id, true, "تم التسليم (ممتاز)")
        }
    }

    fun completeExam(id: Long, obtainedMarks: Int) {
        viewModelScope.launch {
            repository.updateExamResult(id, true, obtainedMarks)
        }
    }

    fun addAssignment(title: String, subject: String, description: String, dueDate: String) {
        viewModelScope.launch {
            val asn = AssignmentEntity(
                title = title,
                subject = subject,
                description = description,
                dueDate = dueDate,
                isSubmitted = false
            )
            repository.insertAssignment(asn)
            try {
                firestore.collection("assignments").add(
                    mapOf(
                        "title" to title,
                        "subject" to subject,
                        "description" to description,
                        "dueDate" to dueDate,
                        "isSubmitted" to false
                    )
                )
            } catch (_: Exception) {}
        }
    }

    fun addAnnouncement(title: String, content: String, sender: String) {
        viewModelScope.launch {
            val ann = AnnouncementEntity(
                title = title,
                content = content,
                date = "اليوم",
                sender = sender
            )
            repository.insertAnnouncement(ann)
            try {
                firestore.collection("announcements").add(
                    mapOf(
                        "title" to title,
                        "content" to content,
                        "date" to "اليوم",
                        "sender" to sender
                    )
                )
            } catch (_: Exception) {}
        }
    }

    fun recordAttendance(studentName: String, status: String, className: String) {
        viewModelScope.launch {
            val att = AttendanceEntity(
                studentName = studentName,
                date = "اليوم",
                status = status,
                className = className
            )
            repository.insertAttendance(att)
        }
    }

    fun addSubject(name: String, teacherName: String, className: String, scheduleTime: String) {
        viewModelScope.launch {
            val sub = SubjectEntity(
                name = name,
                teacherName = teacherName,
                className = className,
                scheduleTime = scheduleTime
            )
            repository.insertSubject(sub)
        }
    }
}
