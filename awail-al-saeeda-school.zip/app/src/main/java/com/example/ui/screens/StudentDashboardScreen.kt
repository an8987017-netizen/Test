package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.viewmodel.SchoolViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentDashboardScreen(
    viewModel: SchoolViewModel,
    onNavigateToExam: (Long) -> Unit,
    onNavigateToChat: (String) -> Unit,
    onLogout: () -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    val subjects by viewModel.subjects.collectAsState()
    val assignments by viewModel.assignments.collectAsState()
    val exams by viewModel.exams.collectAsState()
    val announcements by viewModel.announcements.collectAsState()
    val userName by viewModel.currentUserName.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🎓", fontSize = 22.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(userName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("طالب - الصف الأول الثانوي", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onLogout) {
                        Icon(Icons.Default.Logout, contentDescription = "تسجيل الخروج", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") }, selected = tab == 0, onClick = { tab = 0 })
                NavigationBarItem(icon = { Icon(Icons.Default.Book, null) }, label = { Text("المواد") }, selected = tab == 1, onClick = { tab = 1 })
                NavigationBarItem(icon = { Icon(Icons.Default.Assignment, null) }, label = { Text("المهام") }, selected = tab == 2, onClick = { tab = 2 })
                NavigationBarItem(icon = { Icon(Icons.Default.Chat, null) }, label = { Text("المحادثات") }, selected = tab == 3, onClick = { tab = 3 })
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            when (tab) {
                0 -> {
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("أهلاً بك يا $userName!", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("تابع واجباتك واختباراتك بكل سهولة ويسر عبر منصة مدرسة أوائل السعيدة.", color = MaterialTheme.colorScheme.onPrimaryContainer)
                                    }
                                    Text("🌟", fontSize = 36.sp)
                                }
                            }
                        }
                        item { Text("الإعلانات المدرسية", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                        items(announcements) { ann ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(ann.title, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(ann.content, style = MaterialTheme.typography.bodyMedium)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("${ann.sender} • ${ann.date}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                        item { Text("الاختبارات", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                        items(exams) { exam ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(exam.title, fontWeight = FontWeight.Bold)
                                        Text("${exam.subject} • ${exam.durationMinutes} دقيقة", style = MaterialTheme.typography.bodySmall)
                                        if (exam.isCompleted) Text("النتيجة: ${exam.obtainedMarks}/${exam.totalMarks}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                    }
                                    Button(onClick = { onNavigateToExam(exam.id) }) {
                                        Text(if (exam.isCompleted) "مراجعة" else "ابدأ")
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item { Text("المواد الدراسية", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                        items(subjects) { sub ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("📚", fontSize = 28.sp)
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(sub.name, fontWeight = FontWeight.Bold)
                                        Text("المعلم: ${sub.teacherName}", style = MaterialTheme.typography.bodySmall)
                                        Text("الموعد: ${sub.scheduleTime}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item { Text("الواجبات والمهام", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                        items(assignments) { asn ->
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row {
                                        Text(asn.subject, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                        Spacer(modifier = Modifier.weight(1f))
                                        Text(asn.dueDate, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(asn.title, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(asn.description, style = MaterialTheme.typography.bodyMedium)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                        if (asn.isSubmitted) {
                                            Badge { Text(asn.grade ?: "تم التسليم", modifier = Modifier.padding(4.dp)) }
                                        } else {
                                            Button(onClick = { viewModel.submitAssignment(asn.id) }) {
                                                Text("تسليم الحل")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                3 -> {
                    val rooms = listOf("مجموعة أول ثانوي", "نقاشات الرياضيات", "الإدارة المدرسية")
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item { Text("مجموعات المحادثة", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                        items(rooms) { room ->
                            Card(modifier = Modifier.clickable { onNavigateToChat(room) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("💬", fontSize = 24.sp)
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(room, fontWeight = FontWeight.Bold)
                                        Text("انقر لدخول الغرفة", style = MaterialTheme.typography.bodySmall)
                                    }
                                    Icon(Icons.Default.ArrowForwardIos, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
